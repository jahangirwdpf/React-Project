import React from 'react'

function contact() {
  return (
    <div>
      Hello!
    </div>
  )
}

export default contact
