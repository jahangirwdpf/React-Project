
    function footer(){
        
        return(
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark text-light">
                <div class="container-fluid">
                    <h5>All Rights Reserve @2023</h5>
                </div>
            </nav> 
        )
    }
    
    export default footer
